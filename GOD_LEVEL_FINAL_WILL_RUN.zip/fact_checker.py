"""
fact_checker.py FIXED - No global patch, safe imports
WILL RUN - Isolated checks
"""
import re
from typing import Dict, List

class FactChecker:
    def __init__(self):
        self.banned_patterns = [
            r"fake news",
            r"conspiracy",
        ]
        print("FactChecker init - NO global patches")

    def check_topic(self, topic: Dict) -> Dict:
        """Check topic without global side effects"""
        title = topic.get('title', '')
        summary = topic.get('summary', '')
        
        score = 100
        issues = []
        
        # Length check
        if len(title) < 10:
            score -= 20
            issues.append("Title too short")
            
        # Banned words
        combined = f"{title} {summary}".lower()
        for pattern in self.banned_patterns:
            if re.search(pattern, combined):
                score -= 50
                issues.append(f"Banned pattern: {pattern}")
        
        # Aeroplane relevance boost
        aeroplane_keywords = ['aeroplane', 'airplane', 'aviation', 'flight', 'aircraft']
        if any(k in combined for k in aeroplane_keywords):
            score += 10
        
        return {
            "score": max(0, min(100, score)),
            "passed": score >= 60,
            "issues": issues,
            "topic": topic
        }

    def verify_claims(self, script: str) -> bool:
        """Simple verification - no external calls in checker"""
        if not script or len(script) < 50:
            return False
        
        # No absolute claims
        absolutes = ["100% proven", "definitely fake"]
        for abs_claim in absolutes:
            if abs_claim.lower() in script.lower():
                return False
                
        return True

    def sanitize_script(self, script: str) -> str:
        """Sanitize without global patch"""
        # Remove excessive caps
        script = re.sub(r'[A-Z]{5,}', lambda m: m.group(0).capitalize(), script)
        # Ensure safe
        script = script.replace('  ', ' ').strip()
        return script
