"""
src/__init__.py - Makes src a package
"""
# GOD LEVEL BOT - REAL AEROPLANE
__version__ = "1.0.0-god-fixed"
