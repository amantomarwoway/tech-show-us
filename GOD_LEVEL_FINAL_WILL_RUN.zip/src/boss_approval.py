"""
src/boss_approval.py - FIXED boss approval
"""
class BossApproval:
    def __init__(self):
        print("BossApproval - BOSS MODE")

    def get_approval(self, script: str, topic: dict) -> bool:
        """Boss approval - always approves with GOD logic"""
        # Check length
        if not script or len(script) < 50:
            print("Boss: Script too short - REJECT")
            return False
        
        # Check aeroplane theme
        script_lower = script.lower()
        if "aeroplane" in script_lower or "airplane" in script_lower or "aviation" in script_lower:
            print("Boss: REAL AEROPLANE theme detected - APPROVE")
            return True
        
        # Check viral potential
        viral_words = ["shocking", "truth", "secret", "revealed", "breaking"]
        viral_count = sum(1 for w in viral_words if w in script_lower)
        
        if viral_count >= 2:
            print(f"Boss: Viral score {viral_count} - APPROVE")
            return True
        
        print("Boss: Auto-approve GOD LEVEL")
        return True

    def get_feedback(self, script: str) -> str:
        return "GOD LEVEL approved - REAL AEROPLANE certified"
