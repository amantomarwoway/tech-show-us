"""
src/config.py - FIXED GOD CONFIG
"""
import os
from pathlib import Path

class GodConfig:
    def __init__(self):
        self.BASE_DIR = Path(__file__).parent.parent
        self.GOD_DATA_DIR = self.BASE_DIR / "god_data"
        self.OUTPUT_DIR = self.BASE_DIR / "output"
        
        self.GOD_DATA_DIR.mkdir(exist_ok=True)
        self.OUTPUT_DIR.mkdir(exist_ok=True)
        
        # Retention
        self.ATEMPO_FACTOR = 1.11
        self.TARGET_DURATION = 35
        
        # Aeroplane theme
        self.THEME = "REAL AEROPLANE"
        self.BRAND = "GOD LEVEL BOT"
        
        # Fallbacks
        self.FALLBACK_TOPICS = [
            "Real Aeroplane Mystery - Scientists Baffled",
            "Aviation Breakthrough Changes Everything",
            "Secret Aeroplane Technology Revealed",
            "Why Real Aeroplanes Defy Physics - Truth"
        ]

GOD_CONFIG = GodConfig()
