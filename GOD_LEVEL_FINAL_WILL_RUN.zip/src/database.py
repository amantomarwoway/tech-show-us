"""
src/database.py - FIXED simple file DB - no external deps
"""
import json
from pathlib import Path
from datetime import datetime
from src.config import GOD_CONFIG

class GodDatabase:
    def __init__(self):
        self.db_path = GOD_CONFIG.GOD_DATA_DIR / "god_db.json"
        self.data = self._load()
    
    def _load(self):
        if self.db_path.exists():
            try:
                return json.loads(self.db_path.read_text())
            except:
                return {"runs": [], "topics": []}
        return {"runs": [], "topics": []}
    
    def _save(self):
        try:
            self.db_path.write_text(json.dumps(self.data, indent=2))
        except Exception as e:
            print(f"DB save warning: {e}")
    
    def add_topic(self, topic):
        self.data["topics"].append({
            "topic": topic,
            "timestamp": datetime.now().isoformat()
        })
        # Keep last 100
        self.data["topics"] = self.data["topics"][-100:]
        self._save()
    
    def log_run(self, success=True, meta=None):
        self.data["runs"].append({
            "success": success,
            "timestamp": datetime.now().isoformat(),
            "meta": meta or {}
        })
        self.data["runs"] = self.data["runs"][-50:]
        self._save()
    
    def get_recent_topics(self, n=5):
        return [t["topic"] for t in self.data["topics"][-n:]]
