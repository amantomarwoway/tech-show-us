"""
src/editor_god.py - FIXED GOD editor
"""
import os

class EditorGod:
    def __init__(self):
        self.has_openai = bool(os.getenv("OPENAI_API_KEY"))
        print(f"EditorGod - OpenAI: {self.has_openai}")

    def generate_script(self, topic: dict) -> str:
        """Generate script - FIXED with fallback"""
        title = topic.get('title', 'GOD LEVEL NEWS')
        
        # Try OpenAI if key present
        if self.has_openai:
            try:
                from openai import OpenAI
                client = OpenAI()
                prompt = f"""Write 300 word YouTube short script about: {title}
                Style: GOD LEVEL, REAL AEROPLANE, retention hooks, shocking, viral.
                Structure: Hook (5s), Build (20s), Payoff (10s).
                End with CTA.
                """
                resp = client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=500
                )
                script = resp.choices[0].message.content
                if script and len(script) > 100:
                    print("✓ OpenAI script generated")
                    return script
            except Exception as e:
                print(f"OpenAI failed, fallback: {e}")

        # GUARANTEED FALLBACK SCRIPT - WILL ALWAYS WORK
        fallback_script = f"""
What if I told you {title} is NOT what you think?

For years, aviation experts lied to us about REAL AEROPLANES.

Here's the shocking truth they don't want you to know.

Number one, real aeroplanes use secret aerodynamic principles discovered in 1947 but hidden from public.

Number two, every commercial flight you took was actually using this hidden technology.

Number three, this changes everything about how we understand flight.

Wait, this will shock you - the proof is in declassified documents that were just released.

But here's what they don't tell you - this technology was originally designed for something else entirely.

The real truth is even crazier - and I'm about to show you exclusive footage that proves it.

This is GOD LEVEL aviation truth. If this video reaches 1000 likes, I'll release part 2 with actual blueprints.

Comment REAL if you want the truth. Subscribe for GOD LEVEL reveals.

This is not conspiracy, this is REAL AEROPLANE science.
"""
        print("✓ Fallback script generated - guaranteed")
        return fallback_script.strip()
