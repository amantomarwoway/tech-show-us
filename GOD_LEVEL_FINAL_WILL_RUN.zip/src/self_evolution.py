"""
src/self_evolution.py - FIXED self evolution
"""
from src.database import GodDatabase
from datetime import datetime

class SelfEvolution:
    def __init__(self):
        self.db = GodDatabase()
        print("SelfEvolution - EVOLVING")

    def log_run(self, topic, script, success=True):
        """Log run for evolution"""
        try:
            self.db.log_run(success=success, meta={
                "topic_title": topic.get('title',''),
                "script_length": len(script),
                "category": topic.get('category',''),
                "timestamp": datetime.now().isoformat()
            })
            print(f"✓ Run logged - Success: {success}")
        except Exception as e:
            print(f"Log warning: {e}")

    def get_insights(self):
        """Get evolution insights"""
        runs = self.db.data.get("runs", [])
        success_rate = sum(1 for r in runs if r.get("success")) / len(runs) if runs else 1.0
        
        return {
            "total_runs": len(runs),
            "success_rate": success_rate,
            "evolution_status": "GOD LEVEL - improving",
            "next_optimization": "Increase atempo to 1.12 if retention < 50%"
        }

    def should_evolve(self):
        insights = self.get_insights()
        return insights["total_runs"] > 5
