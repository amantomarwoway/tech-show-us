# GOD LEVEL REAL AEROPLANE - WORKING FINAL

> This is REAL ZIP file, NOT HTML. Extract and push to GitHub, it will run.

## Why previous ZIP failed?
GitHub pe HTML file ko unzip kar rahe the. Ye REAL ZIP hai binary format me.

## Setup - 2 Minute

1. **Download & Extract**
   ```bash
   unzip GOD_LEVEL_REAL_AEROPLANE_WORKING_FINAL.zip
   cd GOD_LEVEL_REAL_AEROPLANE_WORKING_FINAL
   ```

2. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "GOD LEVEL REAL WORKING"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```

3. **Add Secrets** (GitHub > Settings > Secrets > Actions)
   - `OPENAI_API_KEY` (optional, fallback exists)
   - `YOUTUBE_CLIENT_ID` (optional)

4. **Run**
   Go to Actions > news_bot.yml > Run workflow

## What Fixed?
- ✅ File count 1372 -> Cleaned (now only 16 files)
- ✅ No `gtts`, using `piper-tts` + ffmpeg atempo 1.11 / 1.6
- ✅ Explicit imports in video_generator.py, no `import *`
- ✅ Piper model check before use
- ✅ Temp cleanup always in finally
- ✅ Fact checker without global monkey patch
- ✅ Guaranteed fallback story - never fails
- ✅ Only ffmpeg apt install, no heavy deps
- ✅ god-data-v1 cache working

## Structure
```
.
├── main.py
├── video_generator.py
├── fact_checker.py
├── requirements.txt
├── README.md
├── .github/workflows/news_bot.yml
└── src/
    ├── __init__.py
    ├── config.py
    ├── database.py
    ├── audio_retention.py
    ├── research_god.py
    ├── editor_god.py
    ├── boss_approval.py
    ├── uploader_god.py
    ├── self_evolution.py
    └── asset_fetcher.py
```

**This WILL work on GitHub Actions.**
