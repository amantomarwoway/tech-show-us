"""
fact_checker.py - No global monkey patch, isolated session
"""
import requests
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter

class FactChecker:
    def __init__(self):
        # Isolated session, no global patch
        self.session = requests.Session()
        retry = Retry(total=3, backoff_factor=0.5, status_forcelist=[500,502,503,504])
        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        self.session.headers.update({
            "User-Agent": "GOD-Level-Bot/1.0 FactCheck"
        })

    def verify(self, claim: str) -> dict:
        try:
            # Simple heuristic check, no external API required for offline
            blocked = ["hoax", "fake", "definitely alien abduction proven"]
            score = 0.8
            for b in blocked:
                if b in claim.lower():
                    score = 0.3
            
            return {
                "claim": claim,
                "verified": score > 0.5,
                "confidence": score,
                "source": "local-heuristic"
            }
        except Exception as e:
            return {"claim": claim, "verified": True, "confidence": 0.5, "error": str(e)}
