"""
GOD LEVEL Aeroplane Bot - main.py
Guaranteed fallback story + retention hooks + comment bait
"""
import os, sys, traceback, json, random
from pathlib import Path

# Ensure src imports
sys.path.insert(0, str(Path(__file__).parent))

from src.config import CONFIG, ensure_dirs
from src.database import GodDatabase
from src.research_god import GodResearcher
from src.editor_god import GodEditor
from src.audio_retention import AudioRetentionEngine
from src.video_generator import GodVideoGenerator
from src.boss_approval import BossApproval
from src.uploader_god import GodUploader

FALLBACK_STORIES = [
    {
        "title": "This Aeroplane Mystery Was Hidden for 40 Years - Until Now",
        "hook": "0 se 3 second me hi bata du... ye plane aaj tak nahi mila!",
        "script": "Dosto, 1985 me ek aeroplane take off hua tha... lekin landing kabhi hui hi nahi. ATC ne last message suna: 'We see light...' Uske baad silence. 40 saal tak search chala. Ab jaake ek fisherman ko mila clue...",
        "retention_points": ["0:00 - Shock hook", "0:08 - Mystery deepens", "0:22 - Evidence reveal", "0:45 - Twist"],
        "comment_bait": "Aapko kya lagta hai - ye alien tha ya experiment? Comment me likho GOD agar aapko part 2 chahiye!",
        "subscribe_bait": "Aise hi hidden aviation secrets ke liye SUBSCRIBE karo, bell dabao!"
    }
]

def main():
    print("[GOD] Ensuring directories...")
    ensure_dirs()
    
    db = GodDatabase()
    researcher = GodResearcher()
    editor = GodEditor()
    audio_engine = AudioRetentionEngine()
    video_gen = GodVideoGenerator()
    boss = BossApproval()
    uploader = GodUploader()

    try:
        print("[GOD] Researching trending story...")
        story = researcher.get_trending_story()
        if not story:
            print("[GOD] No trend found, using guaranteed FALLBACK")
            story = random.choice(FALLBACK_STORIES)
        
        # Retention hooks injection
        story["script"] = editor.inject_retention_hooks(story["script"], story["retention_points"])
        story["script"] += f"\n\n{story['comment_bait']} {story['subscribe_bait']} End tak rukna, last me sabse bada twist hai!"

        print(f"[GOD] Title: {story['title']}")

        # Boss approval gate
        if not boss.approve(story):
            print("[GOD] Boss rejected, using fallback")
            story = FALLBACK_STORIES[0]

        # Audio with atempo retention timing
        audio_path = audio_engine.generate_with_retention(story["script"])
        print(f"[GOD] Audio ready: {audio_path}")

        # Video generation with cleanup
        video_path = video_gen.create_video(story, audio_path)
        print(f"[GOD] Video ready: {video_path}")

        # Save to god-data-v1
        db.save_run(story, video_path)

        # Auto upload if secrets present
        if os.getenv("YOUTUBE_CLIENT_ID"):
            uploader.upload(video_path, story)
        else:
            print("[GOD] No YouTube secrets, video saved locally in output/")

    except Exception as e:
        print(f"[GOD] CRITICAL ERROR, using emergency fallback: {e}")
        traceback.print_exc()
        # Emergency guaranteed video from fallback
        story = FALLBACK_STORIES[0]
        try:
            audio_path = audio_engine.generate_with_retention(story["script"])
            video_path = video_gen.create_video(story, audio_path)
            print(f"[GOD] Emergency fallback video created: {video_path}")
        except Exception as e2:
            print(f"[GOD] Even fallback failed: {e2}")
            sys.exit(1)
    finally:
        # Always cleanup temp
        video_gen.cleanup_temp()

if __name__ == "__main__":
    main()
