class BossApproval:
    def approve(self, story: dict) -> bool:
        title = story.get("title", "")
        # Simple rules: must contain aeroplane/flight/mystery, >10 chars, no banned words
        banned = ["kill", "terror"]
        if len(title) < 10:
            return False
        for b in banned:
            if b in title.lower():
                return False
        print("[BOSS] Approved:", title)
        return True
