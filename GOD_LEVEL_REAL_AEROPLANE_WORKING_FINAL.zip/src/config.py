from pathlib import Path

CONFIG = {
    "VIDEO_WIDTH": 1920,
    "VIDEO_HEIGHT": 1080,
    "FPS": 24,
    "VOICE_SPEED_SLOW": 1.11,
    "VOICE_SPEED_FAST": 1.6,
    "RETENTION_HOOK_INTERVAL": 8,
    "CACHE_DIR": "god-data-v1",
    "MODEL_DIR": "models",
}

def ensure_dirs():
    for d in ["src", "output", "temp", "models", "data", "god-data-v1", ".github/workflows"]:
        Path(d).mkdir(parents=True, exist_ok=True)
