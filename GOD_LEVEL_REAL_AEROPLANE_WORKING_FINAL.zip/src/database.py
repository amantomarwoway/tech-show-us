import sqlite3
from pathlib import Path
import json
from datetime import datetime

class GodDatabase:
    def __init__(self, db_path="god-data-v1/god.db"):
        Path("god-data-v1").mkdir(exist_ok=True)
        self.conn = sqlite3.connect(db_path)
        self._init()

    def _init(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS runs (
                id INTEGER PRIMARY KEY,
                title TEXT,
                video_path TEXT,
                created_at TEXT,
                meta TEXT
            )
        """)
        self.conn.commit()

    def save_run(self, story: dict, video_path: str):
        self.conn.execute(
            "INSERT INTO runs (title, video_path, created_at, meta) VALUES (?,?,?,?)",
            (story["title"], video_path, datetime.utcnow().isoformat(), json.dumps(story))
        )
        self.conn.commit()
        print("[DB] Saved run")
