class GodEditor:
    def inject_retention_hooks(self, script: str, points: list) -> str:
        hooks = {
            0: "Ruko! Sabse bada sach end me hai!",
            1: "Lekin asli twist abhi baaki hai...",
            2: "Ye sunke aapke hosh ud jayenge!"
        }
        parts = script.split(". ")
        out = []
        for i, p in enumerate(parts):
            out.append(p)
            if i in hooks:
                out.append(f"[{hooks[i]}]")
        return ". ".join(out)
