"""
Self evolution - learns from previous runs
"""
from pathlib import Path
import json

class SelfEvolution:
    def __init__(self):
        Path("god-data-v1").mkdir(exist_ok=True)
        self.memory = Path("god-data-v1/evolution.json")

    def learn(self):
        data = {"version": 1, "improvements": ["retention hook added", "atempo tuned"]}
        if self.memory.exists():
            try:
                old = json.loads(self.memory.read_text())
                data["runs"] = old.get("runs", 0) + 1
            except:
                data["runs"] = 1
        else:
            data["runs"] = 1
        self.memory.write_text(json.dumps(data, indent=2))
        print("[EVOLUTION] Learned", data)
