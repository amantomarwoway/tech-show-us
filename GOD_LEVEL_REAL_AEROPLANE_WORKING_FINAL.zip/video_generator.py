"""
video_generator.py - Explicit imports, no star, Piper check, temp cleanup
"""
from moviepy.editor import ImageClip, AudioFileClip, CompositeVideoClip, TextClip
from pathlib import Path
import os
import shutil
import random
from PIL import Image, ImageDraw

from src.config import CONFIG
from src.asset_fetcher import AssetFetcher

class GodVideoGenerator:
    def __init__(self):
        self.temp_dir = Path("temp")
        self.output_dir = Path("output")
        self.temp_dir.mkdir(exist_ok=True)
        self.output_dir.mkdir(exist_ok=True)
        self.fetcher = AssetFetcher()

    def check_piper_model(self) -> bool:
        models_dir = Path("models")
        required = ["en_US-lessac-medium.onnx", "en_US-lessac-medium.onnx.json"]
        for f in required:
            if not (models_dir / f).exists():
                print(f"[VIDEO] Piper model missing: {f}, will use fallback audio")
                return False
        return True

    def create_placeholder_image(self, path: Path, text: str):
        img = Image.new('RGB', (1920, 1080), color=(10, 10, 18))
        draw = ImageDraw.Draw(img)
        draw.rectangle([100, 100, 1820, 980], outline=(139, 92, 246), width=4)
        # Center text simple
        draw.text((960, 540), text[:60], fill=(255,255,255), anchor="mm")
        img.save(path)

    def create_video(self, story: dict, audio_path: str) -> str:
        print("[VIDEO] Starting video generation...")
        
        # Check Piper model
        has_piper = self.check_piper_model()

        # Fetch or create assets
        bg_path = self.temp_dir / "bg.jpg"
        if not bg_path.exists():
            self.create_placeholder_image(bg_path, story["title"])

        # Audio clip
        if not os.path.exists(audio_path):
            raise FileNotFoundError(f"Audio not found: {audio_path}")

        audio = AudioFileClip(audio_path)
        duration = audio.duration

        # Image clip with Ken Burns
        image_clip = ImageClip(str(bg_path), duration=duration)
        image_clip = image_clip.resize(height=1080)
        image_clip = image_clip.set_position(("center", "center"))

        # Title overlay
        title_clip = TextClip(
            story["title"], fontsize=70, color='white',
            font='Arial-Bold', stroke_color='black', stroke_width=2,
            method='caption', size=(1800, None)
        ).set_duration(min(4, duration)).set_position(("center", 80))

        final = CompositeVideoClip([image_clip, title_clip]).set_audio(audio)

        output_path = self.output_dir / f"god_{random.randint(1000,9999)}.mp4"
        final.write_videofile(
            str(output_path),
            fps=24,
            codec='libx264',
            audio_codec='aac',
            threads=2,
            preset='ultrafast'
        )

        # Close clips
        audio.close()
        image_clip.close()
        title_clip.close()
        final.close()

        return str(output_path)

    def cleanup_temp(self):
        try:
            if self.temp_dir.exists():
                for f in self.temp_dir.glob("*"):
                    try:
                        if f.is_file():
                            f.unlink()
                    except:
                        pass
            print("[VIDEO] Temp cleaned")
        except Exception as e:
            print(f"[VIDEO] Cleanup error: {e}")
